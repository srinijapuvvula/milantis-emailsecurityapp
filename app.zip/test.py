connection = create_connection()
if connection:
    print("Connection successful!")
    connection.close()
