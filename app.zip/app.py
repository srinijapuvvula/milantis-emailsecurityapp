from flask import Flask, render_template, request, redirect, url_for, flash, session
import dns.resolver
import logging
import os
from lxml import etree
from datetime import datetime, timezone
import pytz
import re
import gzip
import zipfile
from io import BytesIO
from azure.storage.blob import BlobServiceClient
import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash, check_password_hash
import bcrypt

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Root@110697",
        database="my_database"
    )









app = Flask(__name__)

app.secret_key = '6f9e9b129d1a35222eaea8628a3708033dae8e897c2b4ba3'




# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Get current date and time
current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Azure Blob Storage configuration
AZURE_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=dnsanddmarcsg;AccountKey=1/qyAU9++aFoYCDfwcHxBkMSe4+bJmqL74RzE9Gruri/M4Vz/HxKo/zDVGPjVG47jwPMrd891tho+ASt7kHlGg==;EndpointSuffix=core.windows.net'
CONTAINER_NAME = 'xmlzipfiles'
blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)

# Function to convert epoch time to a readable date format
def epoch_to_date(epoch_time):
    return datetime.fromtimestamp(int(epoch_time)).strftime("%Y-%m-%d")

def epoch_to_est(epoch_time):
    est_timezone = pytz.timezone('America/New_York')
    return datetime.fromtimestamp(int(epoch_time), timezone.utc).astimezone(est_timezone).strftime("%Y-%m-%d %H:%M:%S %Z")

def date_string_to_epoch(date_string):
    est_timezone = pytz.timezone('America/New_York')
    try:
        # First, try parsing with full date, time, and timezone
        dt = datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S %Z")
    except ValueError:
        try:
            # If that fails, try parsing with just the date and add timezone
            dt = datetime.strptime(date_string, "%Y-%m-%d")
            dt = est_timezone.localize(dt)  # Localize to EST timezone
        except ValueError:
            # If that fails too, try removing extra characters like timezone or time components
            cleaned_date_string = date_string.split(" ")[0]  # Only keep the date part
            dt = datetime.strptime(cleaned_date_string, "%Y-%m-%d")
            dt = est_timezone.localize(dt)  # Localize to EST timezone
    return int(dt.timestamp())

from datetime import datetime, timezone
import pytz

def est_to_epoch(est_date_str):
    # Expecting the input date in the format 'YYYY-MM-DD'
    est_datetime = datetime.strptime(est_date_str, "%Y-%m-%d")
    est_timezone = pytz.timezone('America/New_York')
    est_datetime = est_timezone.localize(est_datetime)
    epoch_time = int(est_datetime.timestamp())
    print(f"[DEBUG] Converted EST date '{est_date_str}' to epoch '{epoch_time}'")
    return epoch_time


# Function to parse the DMARC XML file
def parse_dmarc_xml(file_obj):
    try:
        tree = etree.parse(file_obj)
        aggregated_data = {"source_ips": []}
        
        # Extract organization name
        reporting_org = tree.findtext('.//report_metadata/org_name')
        aggregated_data["reporting_org"] = reporting_org if reporting_org else "Unknown Organization"
        
        # Parse date range and convert to EST
        begin_epoch = int(tree.findtext('.//date_range/begin'))
        end_epoch = int(tree.findtext('.//date_range/end'))
        begin_gmt = datetime.fromtimestamp(begin_epoch, timezone.utc)
        end_gmt = datetime.fromtimestamp(end_epoch, timezone.utc)

        est_timezone = pytz.timezone('America/New_York')
        begin_est = begin_gmt.astimezone(est_timezone)
        end_est = end_gmt.astimezone(est_timezone)

        aggregated_data["date_range"] = {
            "begin_gmt": begin_gmt.strftime("%Y-%m-%d %H:%M:%S %Z"),
            "end_gmt": end_gmt.strftime("%Y-%m-%d %H:%M:%S %Z"),
            "begin": begin_est.strftime("%Y-%m-%d %H:%M:%S %Z"),
            "end": end_est.strftime("%Y-%m-%d %H:%M:%S %Z")
        }

        # Extract source IP data from each record
        for record in tree.xpath('//record'):
            source_ip_data = {
                "source_ip": record.findtext('row/source_ip'),
                "disposition": record.findtext('row/policy_evaluated/disposition'),
                "dkim_aligned": record.findtext('row/policy_evaluated/dkim'),
                "spf_aligned": record.findtext('row/policy_evaluated/spf'),
                "spf_domain": record.findtext('auth_results/spf/domain'),
                "spf_scope": record.findtext('auth_results/spf/scope'),
                "spf_authenticated": record.findtext('auth_results/spf/result'),
                "dkim_domain": record.findtext('auth_results/dkim/domain'),
                "dkim_selector": record.findtext('auth_results/dkim/selector'),
                "dkim_authenticated": record.findtext('auth_results/dkim/result'),
            }
            aggregated_data["source_ips"].append(source_ip_data)

        print(f"[DEBUG] Parsed data: {aggregated_data}")

        return aggregated_data
    except Exception as e:
        print(f"Error parsing XML file: {e}")
        print(f"[ERROR] Error parsing XML file: {e}")
        return None

# Extract date range from XML file content, handling both ZIP and GZ formats
def extract_date_range(blob_name):
    blob_client = blob_service_client.get_container_client(CONTAINER_NAME).get_blob_client(blob_name)
    file_data = blob_client.download_blob().readall()

    # Check file type by extension
    if blob_name.endswith('.zip'):
        # Handle ZIP files
        with zipfile.ZipFile(BytesIO(file_data)) as zip_file:
            for file_name in zip_file.namelist():
                if file_name.endswith('.xml'):
                    with zip_file.open(file_name) as xml_file:
                        tree = etree.parse(xml_file)
                        begin_epoch = int(tree.findtext('.//date_range/begin'))
                        end_epoch = int(tree.findtext('.//date_range/end'))
                        begin_date = epoch_to_date(begin_epoch)
                        end_date = epoch_to_date(end_epoch)
                        return begin_date, end_date

    elif blob_name.endswith('.gz'):
        # Handle GZ files
        with gzip.GzipFile(fileobj=BytesIO(file_data)) as gz_file:
            tree = etree.parse(gz_file)
            begin_epoch = int(tree.findtext('.//date_range/begin'))
            end_epoch = int(tree.findtext('.//date_range/end'))
            begin_date = epoch_to_date(begin_epoch)
            end_date = epoch_to_date(end_epoch)
            return begin_date, end_date

    # Return None if the file is neither .zip nor .gz or if an error occurs
    return None, None

# Function to fetch blobs with date ranges and filter by domain
def fetch_blobs_with_date_ranges(domain_filter=None):
    container_client = blob_service_client.get_container_client(CONTAINER_NAME)
    blobs_with_dates = []
    for blob in container_client.list_blobs():
        if blob.name.endswith('.zip') or blob.name.endswith('.gz'):
            begin_date, end_date = extract_date_range(blob.name)
            if begin_date and end_date:
                # Convert begin_date and end_date to EST format for display
                begin_time_est = epoch_to_est(date_string_to_epoch(begin_date))
                end_time_est = epoch_to_est(date_string_to_epoch(end_date))
                domain = blob.name.split('!')[1]  # Extracting the domain
                # Filter based on domain if domain_filter is provided
                if domain_filter is None or domain_filter in domain:
                    blobs_with_dates.append({
                        "name": blob.name,
                        "domain": domain,
                        "begin_time_est": begin_time_est,
                        "end_time_est": end_time_est
                    })
    return blobs_with_dates

@app.route('/aggregate_reports')
def aggregate_reports():
    # Get domain from query parameters for filtering
    domain_filter = request.args.get('domain', None)
    all_blobs = fetch_blobs_with_date_ranges(domain_filter)  # Pass domain_filter to function

    return render_template('aggregate_reports.html', blobs=all_blobs, all_blobs=all_blobs)


@app.route('/filter_reports', methods=['POST'])
def filter_reports():
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    start_epoch = date_string_to_epoch(start_date)
    end_epoch = date_string_to_epoch(end_date)

    # Filter using EST dates
    all_blobs = fetch_blobs_with_date_ranges()
    filtered_blobs = [
        blob for blob in all_blobs
        if date_string_to_epoch(blob['begin_time_est']) >= start_epoch and
           date_string_to_epoch(blob['end_time_est']) <= end_epoch
    ]
    return render_template('aggregate_reports.html', blobs=filtered_blobs, all_blobs=all_blobs)



@app.route('/view_report/<path:blob_name>')
def view_report(blob_name):
    container_client = blob_service_client.get_container_client(CONTAINER_NAME)
    blob_client = container_client.get_blob_client(blob_name)
    
    # Check if it's a .zip file or .gz file and handle accordingly
    if blob_name.endswith('.zip'):
        zip_data = blob_client.download_blob().readall()
        with zipfile.ZipFile(BytesIO(zip_data)) as zip_file:
            for file_name in zip_file.namelist():
                if file_name.endswith('.xml'):
                    with zip_file.open(file_name) as xml_file:
                        data = parse_dmarc_xml(xml_file)
                        return render_template(
                            'results.html',
                            data=[data],
                            domain="modaexperts.com",
                            current_datetime=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            dmarc_report=True
                        )
    
    elif blob_name.endswith('.gz'):
        # Handle .gz file extraction (similar to .zip file)
        gz_data = blob_client.download_blob().readall()
        with gzip.GzipFile(fileobj=BytesIO(gz_data)) as gz_file:
            data = parse_dmarc_xml(gz_file)
            return render_template(
                'results.html',
                data=[data],
                domain="modaexperts.com",
                current_datetime=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                dmarc_report=True
            )
    
    return "Invalid file type."


# Signup Route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email_signup')
        password = request.form.get('password')

        # Hash the password
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        try:
            db = get_db_connection()
            cursor = db.cursor()
            cursor.execute(
                "INSERT INTO users (first_name, last_name, email, password) VALUES (%s, %s, %s, %s)",
                (first_name, last_name, email, hashed_password.decode('utf-8'))
            )
            db.commit()
            cursor.close()
            db.close()
            flash("Account created successfully!", "success")
            return redirect('/login')
        except mysql.connector.Error as e:
            flash(f"Error: {e}", "danger")
            return render_template('signup.html')
    return render_template('signup.html')




# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email_login')
        password = request.form.get('password_login')

        try:
            db = get_db_connection()
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            cursor.close()
            db.close()

            if user and bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
                session['user_id'] = user['id']
                flash("Logged in successfully!", "success")
                return redirect('/dashboard')
            else:
                flash("Invalid email or password.", "danger")
        except mysql.connector.Error as e:
            flash(f"Error: {e}", "danger")
    return render_template('login.html')





# Dashboard Route
@app.route('/dashboard')
def dashboard():
    return render_template('index.html')

# Default Route
@app.route('/')
def default():
    return redirect(url_for('signup'))



# Route for logout
@app.route('/logout')
def logout():
    session.clear()  # Clear all session data
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))



@app.route('/db-check')
def db_check():
    try:
        # Execute a simple query to test the connection
        cursor.execute("SELECT DATABASE();")
        db_name = cursor.fetchone()
        return f"Connected to database: {db_name['DATABASE()']}"
    except mysql.connector.Error as err:
        return f"Error: {err}"






# Route to handle the DMARC report upload based on EST date
@app.route('/dmarc-report', methods=['GET', 'POST'])
def report():
    if request.method == 'POST':
        start_date = request.form.get('start_date')
        
        # Convert start date to epoch time at midnight UTC (assuming input is in "MM-DD-YYYY" format)
        try:
            # Parse start_date as a UTC datetime object at midnight
            start_date_obj = datetime.strptime(start_date, "%m-%d-%Y")
            start_date_utc = datetime(start_date_obj.year, start_date_obj.month, start_date_obj.day, 0, 0, 0, tzinfo=timezone.utc)
            start_epoch = int(start_date_utc.timestamp())
            print(f"Converted start date {start_date} to epoch time (UTC at midnight): {start_epoch}")
        except ValueError:
            return "Invalid date format. Please enter the date in MM-DD-YYYY format."

        # Define the directory where files are located
        uploads_folder = 'uploads'
        os.makedirs(uploads_folder, exist_ok=True)
        
        # Debug: Print the list of files in the directory
        all_files = os.listdir(uploads_folder)
        print("Files in uploads folder:", all_files)
        
        # Search for file with the exact start epoch time in its name
        file_name = next(
            (f for f in all_files if str(start_epoch) in f),
            None
        )

        if not file_name:
            return f"No file found with start date {start_date} (epoch: {start_epoch})"

        file_path = os.path.join(uploads_folder, file_name)
        
        # Handle .gz and .zip files
        if file_name.lower().endswith('.xml'):
            extracted_file_path = file_path  # Use XML directly

        elif file_name.lower().endswith('.zip'):
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                xml_files = [name for name in zip_ref.namelist() if name.endswith('.xml')]
                if xml_files:
                    extracted_file_path = os.path.join(uploads_folder, xml_files[0])
                    zip_ref.extract(xml_files[0], uploads_folder)
                else:
                    return 'No XML file found in the ZIP archive.'

        elif file_name.lower().endswith('.gz'):
            extracted_file_path = os.path.splitext(file_path)[0] + '.xml'
            with gzip.open(file_path, 'rb') as gz_file:
                with open(extracted_file_path, 'wb') as extracted_file:
                    shutil.copyfileobj(gz_file, extracted_file)

        else:
            return 'Invalid file format. Please upload an .xml, .zip, or .gz file.'

        # Parse the extracted XML file (implementation of parse_dmarc_xml function not shown here)
        aggregated_data = parse_dmarc_xml(extracted_file_path)
        os.remove(extracted_file_path)  # Clean up extracted XML file if it was decompressed

        if aggregated_data:
            current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return render_template('results.html', data=aggregated_data, domain="modaexperts.com", current_datetime=current_datetime, dmarc_report=True)
        else:
            return 'No DMARC report data found in the .xml file or parsing error.'

    return render_template('index.html')

def get_dns_hosting_provider(domain):
    try:
        dns_records = dns.resolver.resolve(domain, 'NS')
        nameservers = [ns.target.to_text() for ns in dns_records]

        if any('domaincontrol.com' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'GoDaddy'"
        elif any('cloudflare.com' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Cloudflare'"
        elif any('dnsmadeeasy.com' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'dnsmadeeasy'"         
        elif any('google' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Google'"
        elif any('googledomains' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Google'"       
        elif any('amazonaws.com' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Amazon'"
        elif any('awsdns' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Amazon'"
        elif any('opendns' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'OpenDNS - Cisco Umbrella'"
        elif any('openns' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'OpenDNS - Cisco Umbrella'"  
        elif any('azure-dns' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Azure DNS'"
        elif any('ns1.com' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'IBM NS1'"
        elif any('nsone' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'NS1'"
        elif any('ns4' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'ns4'"
        elif any('akam.net' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Akamai Technologies'"
        elif any('ultradns' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Neustar UltraDNS'"
        elif any('cloudns' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'ClouDNS'"
        elif any('dynect' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Dyn - Oracle Cloud Infrastructure'"
        elif any('easydns' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'EasyDNS'"
        elif any('registrar-servers' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Namecheap'"
        elif any('bluehost' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'Bluehost'"
        elif any('dreamhost' in ns for ns in nameservers):
            return f"Your DNS hosting provider for {domain} is 'DreamHost'"
        else:
            return f"No recognized DNS hosting provider found for {domain}"
    except dns.resolver.NXDOMAIN:
        return None


def dns_hosting_provider(domain):
    try:
        ns_records = dns.resolver.resolve(domain, 'NS')
        hosting_providers = [ns.target.to_text() for ns in ns_records]
        if hosting_providers:
            return f"Name Server records for {domain}: {', '.join(hosting_providers)}"
        else:
            return None
    except dns.resolver.NXDOMAIN:
        return None

def mx_lookup(domain):
    try:
        mx_records = dns.resolver.resolve(domain, 'MX')
        mx_results = [f"{mx.exchange} (Preference: {mx.preference})" for mx in mx_records]

    except dns.resolver.NXDOMAIN:
        mx_results = None
    return mx_results

def dmarc_lookup(domain):
    try:
        dmarc_records = dns.resolver.resolve(f'_dmarc.{domain}', 'TXT')
        dmarc_results = [f"{record}" for record in dmarc_records]

    except dns.resolver.NXDOMAIN:
        dmarc_results = None
    return dmarc_results

def dkim_lookup(domain):
    try:
        dkim_records = dns.resolver.resolve(f'selector1._domainkey.{domain}', 'TXT')
        dkim_results = [f"{record}" for record in dkim_records]
    except dns.resolver.NXDOMAIN:
        dkim_results = None
    return dkim_results

def spf_lookup(domain):
    try:
        spf_records = dns.resolver.resolve(domain, 'TXT')
        spf_results = [record.strings[0].decode('utf-8') for record in spf_records if record.strings and record.strings[0].startswith(b"v=spf1")]
    except dns.resolver.NXDOMAIN:
        spf_results = None
    return spf_results

def dns_lookup(domain):
    try:
        dns_records = dns.resolver.resolve(domain, 'A')
        dns_results = [f"{record}" for record in dns_records]

    except dns.resolver.NoAnswer:
        # If no A record, try looking up a CNAME record
        try:
            cname_record = dns.resolver.resolve(domain, 'CNAME')
            dns_results = [f"CNAME found: {str(record)}" for record in cname_record]
        except dns.resolver.NoAnswer:
            # No A or CNAME record found
            dns_results = ["No A or CNAME record found for this domain."]
        except dns.exception.DNSException as e:
            # Handle other DNS-related errors
            return [f"Error retrieving CNAME record: {e}"]
        # return ["No A record found for this domain."]
    except dns.resolver.NXDOMAIN:
        dns_results = None   
    except dns.resolver.Timeout:
        return ["DNS query timed out."]
    except dns.exception.DNSException as e:
        return [f"Error retrieving DNS record: {e}"]
    return dns_results

def mta_sts_lookup(domain):
    try:
        mta_sts_records = dns.resolver.resolve(f"_mta-sts.{domain}", 'TXT')
        mta_sts_results = [record.strings[0] for record in mta_sts_records]
        return mta_sts_results
    except dns.resolver.NXDOMAIN:
        return None


def txt_lookup(domain):
    try:
        txt_records = dns.resolver.resolve(domain, 'TXT')
        txt_results = [f"{record}" for record in txt_records]
    except dns.resolver.NXDOMAIN:
        txt_results = None
    return txt_results

@app.route('/index', methods=['GET', 'POST'])
def index():
    return render_template('index.html')
	

# Route to get DNS information and perform lookups
@app.route('/emailsecurity-results', methods=['POST'])
def results():
    domain = request.form['domain']
    mx_results = mx_lookup(domain)
    dmarc_results = dmarc_lookup(domain)
    dkim_results = dkim_lookup(domain)  
    spf_results = spf_lookup(domain)   
    dns_results = dns_lookup(domain)
    mta_sts_results = mta_sts_lookup(domain)
    txt_results = txt_lookup(domain)
    hosting_provider = dns_hosting_provider(domain)
    dns_provider = get_dns_hosting_provider(domain)

    return render_template('results.html', domain=domain, dns_provider=dns_provider, hosting_provider=hosting_provider, txt_results=txt_results, mta_sts_results=mta_sts_results, mx_results=mx_results, dmarc_results=dmarc_results, dkim_results=dkim_results, spf_results=spf_results, dns_results=dns_results, current_datetime=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), email_security=True)

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=8080)